<? require("includes/header.php") ?>
<div class="container">
<!-- F.A.Q. -->
		<section>
			<div class="page-header" id="section-faq">
				<h2>Frequently Asked Questions. <small>A little Q&amp;A to get you started.</small></h2>
			</div> <!-- end page-header -->

			<div class="panel-group" id="accordion-qa">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-1" data-toggle="collapse" data-parent="#accordion-qa">Question 1</a></h4>
					</div>
					<div class="panel-collapse collapse in" id="qa-1">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium, voluptates, sint, doloremque porro corporis atque ullam sapiente placeat iusto repellendus et dicta ut architecto! Cupiditate, facilis itaque pariatur accusamus odit.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->

				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-2" data-toggle="collapse" data-parent="#accordion-qa">Question 2</a></h4>
					</div>
					<div class="panel-collapse collapse" id="qa-2">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium, voluptates, sint, doloremque porro corporis atque ullam sapiente placeat iusto repellendus et dicta ut architecto! Cupiditate, facilis itaque pariatur accusamus odit.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->

				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-3" data-toggle="collapse" data-parent="#accordion-qa">Question 3</a></h4>
					</div>
					<div class="panel-collapse collapse" id="qa-3">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium, voluptates, sint, doloremque porro corporis atque ullam sapiente placeat iusto repellendus et dicta ut architecto! Cupiditate, facilis itaque pariatur accusamus odit.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->
			</div> <!-- end panel-group -->
		</section>

        </div>
<? include_once("includes/footer.php") ?>        

