<? include_once("includes/header.php") ?>
    <div class="container">
    <!-- DOCUMENT LIBRARY -->
		<section>
			<div class="page-header" id="section-features">
				<h2>Project Library. <small>These are some ongoing projects.</small></h2>
			</div> <!-- end page-header -->

			<div class="row">
				<div class="col-sm-8">
					<h3>Preject Title</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime, dolorem debitis laboriosam fuga repellat impedit consequuntur ipsam inventore voluptas iure.</p>
				</div>
				<div class="col-sm-4">
					<img src="images/placeholder.jpg" alt="Feature image" class="img-responsive">
				</div>
			</div> <!-- end row -->

			<div class="row">
				<div class="col-sm-8">
					<h3>Preject Title</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime, dolorem debitis laboriosam fuga repellat impedit consequuntur ipsam inventore voluptas iure.</p>
				</div>
				<div class="col-sm-4">
					<img src="images/placeholder.jpg" alt="Feature image" class="img-responsive">
				</div>
			</div> <!-- end row -->

			<div class="row">
				<div class="col-sm-8">
					<h3>Preject Title</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime, dolorem debitis laboriosam fuga repellat impedit consequuntur ipsam inventore voluptas iure.</p>
				</div>
				<div class="col-sm-4">
					<img src="images/placeholder.jpg" alt="Feature image" class="img-responsive">
				</div>
			</div> <!-- end row -->
            </section>
            </div>
<? include_once("includes/footer.php") ?>