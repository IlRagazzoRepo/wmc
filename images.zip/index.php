<? include_once("includes/header.php") ?>
	<!-- BANNER -->
	<div class="jumbotron">
		<div class="container text-center">
			<h1>State of the Art Web Development</h1>
			<p>A complex system designed from scratch never works and cannot be patched up to make it work. You have to start over with a working simple system. - John Gall</p>

			<div class="btn-group">
            					<button type="button" class="btn btn-lg btn-default" data-toggle="modal" data-target="#modal-1">Tell us your project</button>
                                				<button type="button" class="btn btn-lg btn-primary" data-toggle="modal" data-target="#modal-1">Subscribe!</button>
			</div> <!-- end btn-group -->
		</div> <!-- end container -->
	</div> <!-- end jumbotron -->



	<div class="container">
		<!-- TESTIMONIALS -->
		<section>
			<div class="page-header" id="section-home">
				<h2>Testimonials. <small>This is what our customers are saying about us.</small></h2>
			</div> <!-- end page-header -->

			<div class="row">
				<div class="col-md-4">
					<blockquote>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit accusamus excepturi labore nihil cumque iusto voluptatem. Porro, possimus, harum.</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
				<div class="col-md-4">
					<blockquote>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit accusamus excepturi labore nihil cumque iusto voluptatem. Porro, possimus, harum.</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
				<div class="col-md-4">
					<blockquote>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit accusamus excepturi labore nihil cumque iusto voluptatem. Porro, possimus, harum.</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
			</div> <!-- end row -->

			<p class="text-center"><em>Wanna tell us about the product? Head over to the contact form.</em></p>
			<p class="text-center"><a href="contact.php" class="btn btn-default">Contact Us</a></p>
		</section>
        
        <div class="container">
		<!-- TESTIMONIALS -->
		<section>
			<div class="page-header" id="section-documentlibrary">
				<h2>Testimonials. <small>This is what our customers are saying about us.</small></h2>
			</div> <!-- end page-header -->
            </section>
            </div>
<? include_once("includes/footer.php") ?>